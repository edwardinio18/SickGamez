<html>
	<head>
		<title>Laurcons/place</title>
		<link rel="stylesheet" href="fullscreen.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	</head>

	<table id="game-container">

		<tr><td>

			<div id="canvas-div" style="width: 100%; height: 100%;">

				<div id="canvas-pan-div">

					<div id="canvas-zoom-div">

						<canvas id="place-canvas">

						</canvas>

					</div>

				</div>

			</div>

		</td></tr>
		<tr style="height: fit-content;"><td style="text-align: center;">
			<span id="timeout-span" style="font-family: Cambria; font-size: 1.5em;"></span>
		</td></tr>
		<tr><td style="text-align: center; height: 55px; min-height: 55px;">

			<div id="color-buttons" style="display: inline-flex;">

			</div>

		</td></tr>

	</table>

	<script src="place.js"></script>
</html>